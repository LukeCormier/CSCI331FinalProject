<?php 
  echo <<<_END
    </div>
        <footer>
            <h3>Find Us on Social media</h3>
                <p>insert social logos with hyperlink to page</p>
            <h3>Need Help? <a href="https://www.google.com/">Google it.</a></h3>
                <p>(000)000-0000 24 Hrs a day or email 123wedontcare@csci331.edu<p>
        </footer>
    </div>
    </body>
</html>
_END;
?>
